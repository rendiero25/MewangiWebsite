const Review = require('../models/Review');
const ReviewComment = require('../models/ReviewComment');
const Perfume = require('../models/Perfume');
const Notification = require('../models/Notification');
const User = require('../models/User');
const { filterBadWords } = require('../utils/moderation');
const { getUploadedUrl } = require('../utils/uploadedMediaUrl');
const mongoose = require('mongoose');

// @desc    Get semua review (approved only untuk public)
// @route   GET /api/reviews
// @access  Public
const getReviews = async (req, res) => {
  try {
    const { page = 1, limit = 25, perfume, search, occasion, season } = req.query;
    const query = { $or: [{ status: 'approved' }, { status: 'pending', hasBeenApproved: true }] };

    if (perfume) query.perfume = perfume;
    if (occasion) query.occasion = occasion;
    if (season) query.season = season;
    if (search) query.$text = { $search: search };

    const reviews = await Review.find(query)
      .populate('author', 'username avatar')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Review.countDocuments(query);

    res.json({
      reviews,
      totalPages: Math.ceil(total / limit),
      currentPage: Number(page),
      total,
    });
  } catch (error) {
    res.status(500).json({ message: 'Gagal mengambil review', error: error.message });
  }
};

// @desc    Get review by ID + komentar
// @route   GET /api/reviews/:id
// @access  Public
const getReviewById = async (req, res) => {
  try {
    const review = await Review.findOneAndUpdate(
      { 
        _id: req.params.id,
        $or: [{ status: 'approved' }, { status: 'pending', hasBeenApproved: true }]
      },
      { $inc: { views: 1 } },
      { new: true }
    ).populate('author', 'username avatar');

    if (!review) {
      return res.status(404).json({ message: 'Review tidak ditemukan' });
    }

    const comments = await ReviewComment.find({ review: review._id })
      .populate('author', 'username avatar')
      .populate({
        path: 'quote',
        populate: { path: 'author', select: 'username' }
      })
      .sort({ createdAt: 1 });

    res.json({ review, comments });
  } catch (error) {
    res.status(500).json({ message: 'Gagal mengambil review', error: error.message });
  }
};

// @desc    Buat review baru (perlu approval admin)
// @route   POST /api/reviews
// @access  Private (verified member)
const createReview = async (req, res) => {
  try {
    const { title, content, occasion, season, perfume } = req.body;
    let rating = req.body.rating;
    
    // Parse rating fields bracket notation if form-data didn't map them
    if (!rating && req.body['rating[longevity]']) {
      rating = {
        longevity: Number(req.body['rating[longevity]']),
        sillage: Number(req.body['rating[sillage]']),
        valueForMoney: Number(req.body['rating[valueForMoney]']),
        overall: Number(req.body['rating[overall]'])
      };
    }

    const review = await Review.create({
      title: filterBadWords(title),
      content: filterBadWords(content),
      author: req.user._id,
      perfume: perfume || null,
      rating,
      occasion,
      season,
      image: req.file ? getUploadedUrl(req) : '',
      status: 'pending',
    });

    await review.populate('author', 'username avatar');

    // Notify admins
    const admins = await User.find({ role: 'admin' });
    await Promise.all(admins.map(admin => 
      Notification.create({
        recipient: admin._id,
        sender: req.user._id,
        type: 'new_review_admin',
        message: `Review baru pending: "${review.title}" oleh ${req.user.username}`,
        link: `/admin`
      })
    ));

    res.status(201).json({
      message: 'Review berhasil dikirim! Menunggu approval admin.',
      review,
    });
  } catch (error) {
    console.error('Create Review Error:', error);
    res.status(500).json({ message: 'Gagal membuat review', error: error.message });
  }
};

// @desc    Update review
// @route   PUT /api/reviews/:id
// @access  Private (author only, hanya saat pending)
const updateReview = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);

    if (!review) {
      return res.status(404).json({ message: 'Review tidak ditemukan' });
    }

    if (review.author.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Tidak memiliki izin' });
    }

    const { title, content, occasion, season } = req.body;
    let rating = req.body.rating;
    if (!rating && req.body['rating[longevity]']) {
      rating = {
        longevity: Number(req.body['rating[longevity]']),
        sillage: Number(req.body['rating[sillage]']),
        valueForMoney: Number(req.body['rating[valueForMoney]']),
        overall: Number(req.body['rating[overall]'])
      };
    }
    review.title = title ? filterBadWords(title) : review.title;
    review.content = content ? filterBadWords(content) : review.content;
    review.rating = rating || review.rating;
    review.occasion = occasion || review.occasion;
    review.season = season || review.season;
    if (req.file) review.image = getUploadedUrl(req);
    review.status = 'pending';
    review.rejectionReason = '';

    await review.save();
    await review.populate('author', 'username avatar');

    // Notify admins
    try {
      const admins = await User.find({ role: 'admin' });
      const socket = require('../socket');
      await Promise.all(admins.map(async (admin) => {
        const notification = await Notification.create({
          recipient: admin._id,
          sender: req.user._id,
          type: 'new_review_admin',
          message: `Review diedit (pending): "${review.title}" oleh ${req.user.username}`,
          link: `/admin`
        });
        socket.getIO().to(admin._id.toString()).emit('new_notification', notification);
      }));
    } catch (notifyErr) {
      console.error('Notification Error (Update Review):', notifyErr);
    }

    res.json(review);
  } catch (error) {
    console.error('Update Review Error:', error);
    res.status(500).json({ message: 'Gagal mengupdate review', error: error.message });
  }
};

// @desc    Hapus review
// @route   DELETE /api/reviews/:id
// @access  Private (author / admin)
const deleteReview = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);

    if (!review) {
      return res.status(404).json({ message: 'Review tidak ditemukan' });
    }

    if (review.author.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Tidak memiliki izin' });
    }

    await ReviewComment.deleteMany({ review: review._id });
    await Review.findByIdAndDelete(req.params.id);

    res.json({ message: 'Review berhasil dihapus' });
  } catch (error) {
    res.status(500).json({ message: 'Gagal menghapus review', error: error.message });
  }
};

// @desc    Tambah komentar ke review
// @route   POST /api/reviews/:id/comments
// @access  Private (verified member)
const addReviewComment = async (req, res) => {
  try {
    const review = await Review.findOne({
      _id: req.params.id,
      $or: [{ status: 'approved' }, { status: 'pending', hasBeenApproved: true }]
    });

    if (!review) {
      return res.status(404).json({ message: 'Review tidak ditemukan' });
    }

    const comment = await ReviewComment.create({
      content: filterBadWords(req.body.content),
      review: review._id,
      author: req.user._id,
      quote: req.body.quoteId || null,
      image: req.file ? getUploadedUrl(req) : '',
    });

    await comment.populate('author', 'username avatar');

    // Notify review author (if not the commenter)
    if (review.author.toString() !== req.user._id.toString()) {
      const notification = await Notification.create({
        recipient: review.author,
        sender: req.user._id,
        type: 'comment_review',
        message: `${req.user.username} mengomentari review Anda: "${review.title}"`,
        link: `/review/${review._id}`
      });

      const socket = require('../socket');
      socket.getIO().to(review.author.toString()).emit('new_notification', notification);
    }

    res.status(201).json(comment);
  } catch (error) {
    res.status(500).json({ message: 'Gagal menambah komentar', error: error.message });
  }
};

// @desc    Like komentar review
// @route   POST /api/reviews/comments/:id/like
// @access  Private
const likeComment = async (req, res) => {
  try {
    const comment = await ReviewComment.findById(req.params.id);
    if (!comment) return res.status(404).json({ message: 'Komentar tidak ditemukan' });

    const userId = req.user._id;
    comment.dislikes = (comment.dislikes || []).filter(id => id.toString() !== userId.toString());

    if ((comment.likes || []).map(id => id.toString()).includes(userId.toString())) {
      comment.likes = comment.likes.filter(id => id.toString() !== userId.toString());
    } else {
      comment.likes = comment.likes || [];
      comment.likes.push(userId);
    }

    await comment.save();
    res.json({ likes: comment.likes, dislikes: comment.dislikes });
  } catch (error) {
    res.status(500).json({ message: 'Gagal menyukai komentar', error: error.message });
  }
};

// @desc    Dislike komentar review
// @route   POST /api/reviews/comments/:id/dislike
// @access  Private
const dislikeComment = async (req, res) => {
  try {
    const comment = await ReviewComment.findById(req.params.id);
    if (!comment) return res.status(404).json({ message: 'Komentar tidak ditemukan' });

    const userId = req.user._id;
    comment.likes = (comment.likes || []).filter(id => id.toString() !== userId.toString());

    if ((comment.dislikes || []).map(id => id.toString()).includes(userId.toString())) {
      comment.dislikes = comment.dislikes.filter(id => id.toString() !== userId.toString());
    } else {
      comment.dislikes = comment.dislikes || [];
      comment.dislikes.push(userId);
    }

    await comment.save();
    res.json({ likes: comment.likes, dislikes: comment.dislikes });
  } catch (error) {
    res.status(500).json({ message: 'Gagal tidak menyukai komentar', error: error.message });
  }
};

// @desc    Get top categories review (occasion + season)
// @route   GET /api/reviews/meta/top-categories
// @access  Public
const getTopCategories = async (req, res) => {
  try {
    const categories = await Review.aggregate([
      { $match: { $or: [{ status: 'approved' }, { status: 'pending', hasBeenApproved: true }] } },
      { 
        $project: { 
          all: { 
            $concatArrays: [
              { $map: { input: { $ifNull: ["$occasion", []] }, as: "o", in: { name: "$$o", type: "occasion" } } },
              { $map: { input: { $ifNull: ["$season", []] }, as: "s", in: { name: "$$s", type: "season" } } }
            ] 
          } 
        } 
      },
      { $unwind: "$all" },
      { $group: { _id: { name: "$all.name", type: "$all.type" }, count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 10 },
      { $project: { _id: 0, name: "$_id.name", type: "$_id.type", count: 1 } }
    ]);
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: 'Gagal mengambil kategori', error: error.message });
  }
};

// @desc    Get related reviews
// @route   GET /api/reviews/:id/related
// @access  Public
const getRelatedReviews = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ message: 'Review tidak ditemukan' });

    const related = await Review.find({
      _id: { $ne: review._id },
      occasion: review.occasion,
      $or: [{ status: 'approved' }, { status: 'pending', hasBeenApproved: true }]
    })
    .limit(5)
    .select('title createdAt');

    res.json(related);
  } catch (error) {
    res.status(500).json({ message: 'Gagal mengambil review terkait', error: error.message });
  }
};

// @desc    Get my reviews (untuk member dashboard)
// @route   GET /api/reviews/my
// @access  Private
const getMyReviews = async (req, res) => {
  try {
    const reviews = await Review.find({ author: req.user._id })
      .sort({ createdAt: -1 });

    res.json(reviews);
  } catch (error) {
    res.status(500).json({ message: 'Gagal mengambil review', error: error.message });
  }
};

// @desc    Hapus komentar dari review
// @route   DELETE /api/reviews/comments/:commentId
// @access  Private (author / admin)
const deleteReviewComment = async (req, res) => {
  try {
    const comment = await ReviewComment.findById(req.params.commentId);

    if (!comment) {
      return res.status(404).json({ message: 'Komentar tidak ditemukan' });
    }

    if (comment.author.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Tidak memiliki izin' });
    }

    await ReviewComment.findByIdAndDelete(req.params.commentId);

    res.json({ message: 'Komentar berhasil dihapus' });
  } catch (error) {
    res.status(500).json({ message: 'Gagal menghapus komentar', error: error.message });
  }
};

// @desc    Like review
// @route   POST /api/reviews/:id/like
// @access  Private
const likeReview = async (req, res) => {
  try {
    const { id } = req.params;
    const review = await Review.findById(id);

    if (!review) return res.status(404).json({ message: "Review tidak ditemukan" });

    const userId = req.user._id;
    const author = await User.findById(review.author);

    let repChange = 0;
    let reactChange = 0;

    if (review.dislikes.includes(userId)) {
      review.dislikes = review.dislikes.filter(id => id.toString() !== userId.toString());
      repChange += 1;
    }

    if (review.likes.includes(userId)) {
      review.likes = review.likes.filter(id => id.toString() !== userId.toString());
      repChange -= 1;
      reactChange -= 1;
    } else {
      review.likes.push(userId);
      repChange += 1;
      reactChange += 1;
    }

    await review.save();

    if (author) {
      author.statistik.reputation += repChange;
      author.statistik.reactions += reactChange;
      await author.save();
    }

    res.json({ likes: review.likes, dislikes: review.dislikes });
  } catch (error) {
    res.status(500).json({ message: "Gagal menyukai review", error: error.message });
  }
};

// @desc    Dislike review
// @route   POST /api/reviews/:id/dislike
// @access  Private
const dislikeReview = async (req, res) => {
  try {
    const { id } = req.params;
    const review = await Review.findById(id);

    if (!review) return res.status(404).json({ message: "Review tidak ditemukan" });

    const userId = req.user._id;
    const author = await User.findById(review.author);

    let repChange = 0;
    let reactChange = 0;

    if (review.likes.includes(userId)) {
      review.likes = review.likes.filter(id => id.toString() !== userId.toString());
      repChange -= 1;
      reactChange -= 1;
    }

    if (review.dislikes.includes(userId)) {
      review.dislikes = review.dislikes.filter(id => id.toString() !== userId.toString());
      repChange += 1;
    } else {
      review.dislikes.push(userId);
      repChange -= 1;
    }

    await review.save();

    res.json({ likes: review.likes, dislikes: review.dislikes });
  } catch (error) {
    res.status(500).json({ message: "Gagal tidak menyukai review", error: error.message });
  }
};

// @desc    Get top reviews (trending)
// @route   GET /api/reviews/meta/top-titles
// @access  Public
const getTopReviews = async (req, res) => {
  try {
    const reviews = await Review.find({
      $or: [{ status: 'approved' }, { status: 'pending', hasBeenApproved: true }]
    })
    .sort({ views: -1 })
    .limit(5)
    .select('title views');

    res.json(reviews);
  } catch (error) {
    res.status(500).json({ message: 'Gagal mengambil review terpopuler', error: error.message });
  }
};

module.exports = { 
  getReviews, getReviewById, createReview, updateReview, deleteReview, addReviewComment, getMyReviews, deleteReviewComment,
  likeComment, dislikeComment, getTopCategories, getRelatedReviews,
  likeReview, dislikeReview, getTopReviews
};
